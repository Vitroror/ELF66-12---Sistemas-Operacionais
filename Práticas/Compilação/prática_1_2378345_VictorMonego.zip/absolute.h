#ifndef ABSOLUTE_H
#define ABSOLUTE_H

double absoluto(double x);

#endif