#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include "absolute.h"

double absoluto(double x)
{
	double y;
	
	y = fabs(x);
	
	return y;
}
